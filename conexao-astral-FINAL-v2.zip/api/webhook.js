// api/webhook.js
// Recebe dados do formulário pós-compra
// Envia e-mail com dados completos para Wellington e confirmação para o cliente

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  try {
    const {
      nome, email, celular,
      data_nascimento, hora_nascimento, tem_hora,
      cidade_nascimento, fonte, pedido, timestamp
    } = req.body;

    if (!email) {
      return res.status(400).json({ error: 'E-mail obrigatório' });
    }

    // ── 1. DISPARA N8N (geração do mapa via IA) ──
    const n8nUrl = process.env.N8N_WEBHOOK_URL;
    if (n8nUrl) {
      await fetch(n8nUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          nome, email, celular,
          data_nascimento, hora_nascimento, tem_hora,
          cidade_nascimento, fonte, pedido,
          timestamp: timestamp || new Date().toISOString()
        })
      }).catch(e => console.error('n8n error:', e));
    }

    // ── 2. E-MAIL PARA WELLINGTON (dados do cliente) ──
    const wellingtonEmail = process.env.WELLINGTON_EMAIL || 'wellington@conexaoastral.com.br';
    const emailWellington = await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${process.env.RESEND_API_KEY}`
      },
      body: JSON.stringify({
        from: 'Conexão Astral <noreply@conexaoastral.com.br>',
        to: wellingtonEmail,
        subject: `🌌 Novo pedido — ${nome}`,
        html: `
          <div style="background:#0D0720;color:#fff;padding:32px;font-family:sans-serif;max-width:500px;border-radius:16px">
            <h2 style="color:#C084FC;margin-bottom:20px">🌌 Novo pedido — Conexão Astral</h2>
            <table style="width:100%;border-collapse:collapse">
              <tr><td style="padding:10px 0;border-bottom:1px solid #2E1858;color:#C4B5D8;font-size:14px">Nome</td><td style="padding:10px 0;border-bottom:1px solid #2E1858;color:#fff;font-weight:600">${nome}</td></tr>
              <tr><td style="padding:10px 0;border-bottom:1px solid #2E1858;color:#C4B5D8;font-size:14px">E-mail</td><td style="padding:10px 0;border-bottom:1px solid #2E1858;color:#fff">${email}</td></tr>
              <tr><td style="padding:10px 0;border-bottom:1px solid #2E1858;color:#C4B5D8;font-size:14px">WhatsApp</td><td style="padding:10px 0;border-bottom:1px solid #2E1858;color:#fff">${celular || 'Não informado'}</td></tr>
              <tr><td style="padding:10px 0;border-bottom:1px solid #2E1858;color:#C4B5D8;font-size:14px">Data de nascimento</td><td style="padding:10px 0;border-bottom:1px solid #2E1858;color:#fff">${data_nascimento}</td></tr>
              <tr><td style="padding:10px 0;border-bottom:1px solid #2E1858;color:#C4B5D8;font-size:14px">Hora de nascimento</td><td style="padding:10px 0;border-bottom:1px solid #2E1858;color:#fff">${hora_nascimento} (${tem_hora})</td></tr>
              <tr><td style="padding:10px 0;color:#C4B5D8;font-size:14px">Cidade de nascimento</td><td style="padding:10px 0;color:#fff">${cidade_nascimento}</td></tr>
            </table>
            <p style="margin-top:24px;font-size:13px;color:#7A5FA0">Pedido recebido em: ${new Date().toLocaleString('pt-BR')}</p>
          </div>
        `
      })
    }).catch(e => console.error('Email Wellington error:', e));

    // ── 3. E-MAIL DE CONFIRMAÇÃO PARA O CLIENTE ──
    await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${process.env.RESEND_API_KEY}`
      },
      body: JSON.stringify({
        from: 'Conexão Astral <noreply@conexaoastral.com.br>',
        to: email,
        subject: `🌌 ${nome}, seus dados foram recebidos!`,
        html: `
          <div style="background:#0D0720;color:#fff;padding:40px;font-family:sans-serif;max-width:560px;border-radius:16px">
            <h1 style="font-family:Georgia,serif;color:#C084FC;font-size:28px;margin-bottom:8px">Recebemos tudo, ${nome}! 🌌</h1>
            <p style="color:#D8C8F0;font-size:16px;line-height:1.7;margin-bottom:28px">
              Seus dados de nascimento chegaram. Nossa análise já está sendo gerada e você receberá seu 
              <strong style="color:#fff">Mapa Astral + Numerologia Completos</strong> em breve.
            </p>
            <div style="background:#1C1035;border-radius:12px;padding:24px;margin-bottom:24px">
              <p style="font-size:14px;color:#7A5FA0;margin-bottom:12px;text-transform:uppercase;letter-spacing:1px">O que está sendo preparado para você</p>
              <p style="font-size:15px;color:#F0E8FF;line-height:1.8;margin:0">
                ✨ Mapa Astral Completo — Sol, Lua, Ascendente, Vênus e Marte<br>
                🔢 Mapa Numerológico — Caminho de Vida, Expressão, Alma e Destino<br>
                💞 Características da sua alma gêmea<br>
                🚀 Ramo de atuação com futuro para o seu perfil<br>
                🔮 Previsão dos próximos 12 meses
              </p>
            </div>
            <p style="font-size:14px;color:#7A5FA0;text-align:center">
              Dúvidas? Responda este e-mail.<br>
              Com carinho, Equipe Conexão Astral 💜
            </p>
          </div>
        `
      })
    }).catch(e => console.error('Email cliente error:', e));

    console.log(`✅ Pedido processado: ${nome} <${email}>`);
    return res.status(200).json({ success: true });

  } catch (error) {
    console.error('Webhook error:', error);
    return res.status(500).json({ error: 'Erro interno' });
  }
}
