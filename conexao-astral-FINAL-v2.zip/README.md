# 🌌 Conexão Astral — Funil Completo

## Arquivos

| Arquivo | Rota | Descrição |
|---|---|---|
| `public/index.html` | `/` | Landing Page principal |
| `public/quiz.html` | `/quiz` | Funil Quiz |
| `public/obrigado.html` | `/obrigado` | Pós-compra + coleta de dados |
| `api/webhook.js` | `/api/webhook` | Recebe dados → envia e-mails → dispara n8n |
| `n8n-workflow.json` | — | Importar no n8n |

## Variáveis de Ambiente no Vercel

| Variável | Valor |
|---|---|
| `N8N_WEBHOOK_URL` | URL do webhook do n8n |
| `RESEND_API_KEY` | Chave da API do Resend (resend.com) |
| `WELLINGTON_EMAIL` | E-mail do Wellington para receber os pedidos |

## Como fazer o deploy

1. Suba este repositório no GitHub
2. Acesse vercel.com/new → Import Git Repository
3. Selecione o repositório `conexao-astral`
4. Adicione as variáveis de ambiente
5. Clique Deploy

## Rotas

- `/` → Landing Page
- `/quiz` → Quiz Funil
- `/obrigado` → Página pós-compra (link para a Cakto enviar no e-mail)
- `/api/webhook` → Endpoint que recebe os dados do formulário

## Link para a Cakto

Configurar como URL pós-compra:
```
https://conexao-astral.vercel.app/obrigado
```

E no e-mail automático da Cakto:
```
https://conexao-astral.vercel.app/obrigado
```
